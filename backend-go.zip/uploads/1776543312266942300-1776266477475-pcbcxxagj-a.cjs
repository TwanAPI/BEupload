const { MongoClient } = require('mongodb');

// Replace with your actual connection string (Atlas or Local)
const uri = "mongodb+srv://admin:Tuan2007@cluster0.c7li2xx.mongodb.net/?appName=Cluster0";

const client = new MongoClient(uri);

async function connectDB() {
  try {
    // Connect to the MongoDB cluster
    await client.connect();
    console.log("Successfully connected to MongoDB!");

    // Access a specific database
    const db = client.db('myDatabase');
    // Do something...

  } catch (error) {
    console.error("Connection error:", error);
  } finally {
    // Keep connection open for the app lifecycle, or close if it's a one-off script
    // await client.close();
  }
}

connectDB();